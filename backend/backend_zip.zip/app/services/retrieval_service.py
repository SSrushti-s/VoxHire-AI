
import uuid

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer


# Load the embedding model only when first needed
_embedding_model = None

# Temporary in-memory storage for uploaded resume indexes
resume_indexes = {}


def get_embedding_model():
    global _embedding_model

    if _embedding_model is None:
        print("Loading sentence embedding model...")

        _embedding_model = SentenceTransformer(
            "sentence-transformers/all-MiniLM-L6-v2"
        )

        print("Embedding model loaded successfully.")

    return _embedding_model


def split_into_chunks(
    text: str,
    chunk_words: int = 150,
    overlap_words: int = 30
):
    """
    Split resume text into overlapping word-based chunks.
    """

    words = text.split()

    if not words:
        return []

    chunks = []
    step = chunk_words - overlap_words

    for start in range(0, len(words), step):
        chunk_words_list = words[start:start + chunk_words]

        if not chunk_words_list:
            break

        chunk = " ".join(chunk_words_list)
        chunks.append(chunk)

        if start + chunk_words >= len(words):
            break

    return chunks


def build_resume_index(resume_text: str):
    """
    Create embeddings and a FAISS index for a resume.
    """

    if not resume_text or not resume_text.strip():
        raise ValueError("Cannot index an empty resume.")

    # Step 1: Split resume into chunks
    chunks = split_into_chunks(resume_text)

    if not chunks:
        raise ValueError("No readable chunks found in resume.")

    print("RESUME CHUNKS CREATED:", len(chunks))

    # Step 2: Generate embeddings
    model = get_embedding_model()

    embeddings = model.encode(
        chunks,
        convert_to_numpy=True,
        normalize_embeddings=True
    )

    embeddings = np.asarray(embeddings, dtype="float32")

    # Step 3: Create FAISS index
    dimension = embeddings.shape[1]

    index = faiss.IndexFlatIP(dimension)
    index.add(embeddings)

    # Step 4: Generate unique resume ID
    resume_id = str(uuid.uuid4())

    # Step 5: Store index and corresponding chunks
    resume_indexes[resume_id] = {
        "index": index,
        "chunks": chunks
    }

    print("FAISS INDEX CREATED:", resume_id)

    return {
        "resume_id": resume_id,
        "chunk_count": len(chunks)
    }


def search_resume(
    resume_id: str,
    query: str,
    top_k: int = 3
):
    """
    Retrieve the most relevant resume chunks for a query.
    """

    if resume_id not in resume_indexes:
        raise KeyError("Resume index not found.")

    if not query or not query.strip():
        raise ValueError("Search query cannot be empty.")

    resume_data = resume_indexes[resume_id]

    index = resume_data["index"]
    chunks = resume_data["chunks"]

    # Step 1: Convert query into an embedding
    model = get_embedding_model()

    query_embedding = model.encode(
        [query],
        convert_to_numpy=True,
        normalize_embeddings=True
    )

    query_embedding = np.asarray(
        query_embedding,
        dtype="float32"
    )

    # Step 2: Search FAISS
    top_k = min(top_k, len(chunks))

    scores, indices = index.search(
        query_embedding,
        top_k
    )

    # Step 3: Return matching chunks
    results = []

    for score, chunk_index in zip(scores[0], indices[0]):

        if chunk_index < 0:
            continue

        results.append({
            "chunk_id": int(chunk_index),
            "similarity_score": round(float(score), 4),
            "text": chunks[int(chunk_index)]
        })

    return results
