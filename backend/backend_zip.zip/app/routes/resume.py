
from fastapi import APIRouter, UploadFile, File, HTTPException

from app.services.resume_service import extract_resume_text
from app.services.resume_analyzer import analyze_resume
from app.services.retrieval_service import build_resume_index, search_resume
from pydantic import BaseModel, Field

router = APIRouter(
    prefix="/api/resume",
    tags=["Resume Intelligence"]
)
class ResumeSearchRequest(BaseModel):
    resume_id: str
    query: str = Field(min_length=3, max_length=1000)
    top_k: int = Field(default=3, ge=1, le=10)

MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB


@router.post("/upload")
async def upload_resume(file: UploadFile = File(...)):

    # Check filename
    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(
            status_code=400,
            detail="Only PDF resume files are supported."
        )

    # Read uploaded file
    pdf_bytes = await file.read()

    # Check file size
    if not pdf_bytes:
        raise HTTPException(
            status_code=400,
            detail="The uploaded file is empty."
        )

    if len(pdf_bytes) > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=413,
            detail="File size must not exceed 10 MB."
        )

    # Verify PDF file signature
    if not pdf_bytes.startswith(b"%PDF-"):
        raise HTTPException(
            status_code=400,
            detail="Invalid PDF file."
        )

    try:
        result = extract_resume_text(pdf_bytes)
        candidate_profile = await analyze_resume(
                    result["extracted_text"]
                )
        index_result = build_resume_index(
                    result["extracted_text"]
                )
        return {
            "success": True,
            "message": "Resume uploaded and text extracted successfully.",
            "filename": file.filename,
            "page_count": result["page_count"],
            "character_count": result["character_count"],
            "resume_id": index_result["resume_id"],
            "indexed_chunks": index_result["chunk_count"],
            "candidate_profile": candidate_profile
        }

    except ValueError as error:
        raise HTTPException(
            status_code=422,
            detail=str(error)
        )

    finally:
        await file.close()
        
@router.post("/search")
async def search_resume_endpoint(request: ResumeSearchRequest):

    try:
        results = search_resume(
            resume_id=request.resume_id,
            query=request.query,
            top_k=request.top_k
        )

        return {
            "success": True,
            "query": request.query,
            "results_count": len(results),
            "retrieved_chunks": results
        }

    except KeyError:
        raise HTTPException(
            status_code=404,
            detail="Resume index not found. Please upload the resume again."
        )

    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )

    except Exception as error:
        print("RESUME SEARCH ERROR:", error)

        raise HTTPException(
            status_code=500,
            detail="Unable to search resume."
        )