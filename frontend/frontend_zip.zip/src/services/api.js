const API_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";

// Upload and analyze a PDF resume
export async function uploadResume(file) {
    const formData = new FormData();

    formData.append("file", file);

    const response = await fetch(`${API_URL}/api/resume/upload`, {
        method: "POST",
        body: formData
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || "Resume upload failed");
    }

    return response.json();
}


// Start a new interview
// resumeId is optional
// Start a new interview using role-based or JD-based configuration
export async function startInterview({
    interviewMode,
    role = null,
    jobDescription = null,
    difficulty,
    resumeId = null
}) {
    const response = await fetch(`${API_URL}/api/interview/start`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            interview_mode: interviewMode,
            role,
            job_description: jobDescription,
            difficulty,
            resume_id: resumeId
        })
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || "Could not start interview");
    }

    return response.json();
}

// Submit a candidate answer
export async function submitAnswer(sessionId, message) {
    const response = await fetch(`${API_URL}/api/interview/respond`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            session_id: sessionId,
            message
        })
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || "Could not submit answer");
    }

    return response.json();
}


// Get final interview report
export async function getInterviewReport(sessionId) {
    const response = await fetch(
        `${API_URL}/api/interview/report/${sessionId}`
    );

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || "Could not fetch report");
    }

    return response.json();
}


// Convert microphone recording into text
export async function transcribeAudio(audioBlob) {
    const formData = new FormData();

    formData.append("file", audioBlob, "recording.webm");

    const response = await fetch(
        `${API_URL}/api/voice/transcribe`,
        {
            method: "POST",
            body: formData
        }
    );

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || "Transcription failed");
    }

    return response.json();
}